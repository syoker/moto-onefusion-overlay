## Changelog

### v1.0.4
- Fix rounded corners on Android 12 & 12.1

### v1.0.3
- Add power_profile and resources

### v1.0.2
- Fix battery use on Android 11

### v1.0.1
- Fix android_check

### v1.0.0
- Initial build